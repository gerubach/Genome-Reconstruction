The zip file contains all the files necessary to run the program (Bioinfo Project.exe). 
When the program is started, it will ask you to enter 1 for the first set of trials and 0 for the second set of trials.

The first set of trials use the de Bruijn algorithm shown in class to construct an arbitrary Eulerian cycle and check if it creates the correct genome (there are no repeats in these trials). 
The program will prompt you for the read length and will terminate after performing 10 trials. 
When the program terminates, it will say "All data has been generated."
The output will be in the text file results.txt. In results.txt there will be a single number which is the number of trials out of 10 that the arbitrary Eulerian cycle that was generated was the same as the original genome.

The second set of trials keep generating random walks until the correct one is generated. The program will prompt you for read length, repeat length, and number of repeats. 
This should go without saying, but putting in negative values for any of these may crash the program. 
Just as in the first set, it will terminate after performing 10 trials, will say "All data has been generated" when it terminates, and the output will be in results.txt.
In results.txt there will be 10 numbers which are the number of random walks generated before success in each trial.

Both sets of trials may take a while to generate data, especially the second set. THIS IS NORMAL. 
For some values of read length, repeat length, and number of repeats the program will take an indefinite amount of time to terminate.
All this means is that the program has, by random chance, had to calculate tens of thousands of random walks for this particular genome. 



